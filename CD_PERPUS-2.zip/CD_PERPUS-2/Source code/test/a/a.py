# from c import *

# # def ba(b):
# # 	c = a + b
# # 	return c
# # print(ba(4))

# def q():
# 	a = ['makan'],['malam']
# 	b = [0.95]
# 	c = [0.03]
# 	qw = 'INSERT INTO `contoh` VALUES (null,"makan");'
# 	q.executemany(qw)
# 	conn.commit()
# 	return

# q()

#! /Users/Refi/AppData/Local/Programs/Python/Python37-32/python
def a():
	a = 4
	b = 5
	c = a+b
	return c

print(a())