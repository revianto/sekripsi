# print("hallo guys")
# s = 'makan malam %s'
# r = s %('1')

# print(r)

a = 3
b = 4 
c = 1
d = 5

if a > b and a > c and a > d:
	print(a)
elif b > c and b > a and b > d:
	print(b)
elif d > c and d > a and d > b:
	print(d)
else:
	print(c) 