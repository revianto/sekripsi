<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
	<form action="b.py" method="post">
		<input type="text" name="text">
		<input type="submit" name="submit" onclick="">
	</form>
</body>
</html>



<!-- <?php
	function openB(){
		window.open("b.php");
	}
?>
 -->

<!-- 
<?php
	echo exec('p.py');
?> -->