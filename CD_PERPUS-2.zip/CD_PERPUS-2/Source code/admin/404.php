<h1 class="display-1">404</h1>
<p class="lead">Page not found. You can
<a href="javascript:history.back()">go back</a>
to the previous page, or
<a href="?page=dashboard">return home</a>.</p>