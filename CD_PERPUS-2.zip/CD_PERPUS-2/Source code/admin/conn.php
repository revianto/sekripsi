<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "ta";
$conn = new mysqli($servername, $username, $password, $db);
?>
