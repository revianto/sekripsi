<?php  

	if (isset($_GET['teks'])) {
		echo $_GET['teks'];
	}else{
		echo "gagal";
	}

?>