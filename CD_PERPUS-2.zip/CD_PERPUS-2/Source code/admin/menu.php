<ul class="sidebar navbar-nav">
        <li class="nav-item act-dash">
          <a class="nav-link act-dash" href="?page=dashboard">
            <i class="fas fa-fw fa-tachometer-alt act-dash"></i>
            <span class="act-dash">Dashboard</span>
          </a>
        </li>
        <li class="nav-item act-abs">
          <a class="nav-link act-abs" href="?page=abstract">
            <i class="fas fa-fw fa-database act-abs"></i>
            <span class="act-abs">Abstract</span></a>
        </li>
        <li class="nav-item act-tfi">
          <a class="nav-link act-tfi" href="?page=tfidf">
            <i class="fas fa-fw fa-chart-area act-tfi"></i>
            <span class="act-tfi">TF-IDF</span></a>
        </li>
        <li class="nav-item act-add-abs">
          <a class="nav-link act-add-abs" href="?page=add">
            <i class="fas fa-fw fa-plus-square act-add-abs"></i>
            <span class="act-add-abs">Add Abstract</span></a>
        </li>
      </ul>

      <div id="content-wrapper">
        <div class="container-fluid">