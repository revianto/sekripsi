from naivebayes import *

print (nbc1)